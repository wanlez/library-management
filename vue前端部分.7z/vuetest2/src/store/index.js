import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    account: '',
    identity: ''
  },
  getters: {
    getAccount: (state) => {
      let account2 = state.account
      return account2
    },
    getIdentity: (state) => {
      let identitiy2 = state.identity
      return identitiy2
    }
  },
  mutations: {
    setAccount (state, payload) {
      state.account = payload
    },
    setIdentity (state, payload) {
      state.identity = payload
    }
  },
  actions: {
  },
  modules: {
  }
})
