import Vue from 'vue'
import './plugins/axios'
import App from './App.vue'
import router from './router'
import store from './store'
import BookManagement from './views/BookManagement'
import './plugins/element.js'
import installElementPlus from './plugins/element'
import Vuex from "vuex";

Vue.config.productionTip = false

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')

const store2 = new Vuex.Store({
  state: {
    account: ''
  },

  getters: {
    getAccount: (state) => {
      let account2 = state.account
      return account2
    }
  },

  mutations: {
    setAccount (state, payload) {
      state.account = payload
    }
  }
})

