import Vue from 'vue'
import VueRouter from 'vue-router'
import Query from "@/views/Query.vue"
import Add from "@/views/Add.vue"
import Update from "@/views/Update.vue"
import Delete from "@/views/Delete.vue"
import BookManagement from "@/views/BookManagement.vue"
import LoginView from "@/views/LoginView";
import Find from "@/views/Find";
import Send from "@/views/Send";
import FindResult from "@/views/FindResult";
import Back from "@/views/Back";
import MyBookCheck from "@/views/MyBookCheck";

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: '图书管理',
    component: BookManagement,
    show: 1,
    admin: 1,
    redirect:'/Login', //Query
    children: [
      {
        path: '/Query',
        name: '查询图书',
        component: Query,
        show: 1,
        admin: 1
      },
      {
        path: '/Query',
        name: '查询图书',
        component: Query,
        show: 1,
        admin: 0
      },
      {
        path: '/MyBookCheck',
        name: '我的图书管理',
        component: MyBookCheck,
        show: 1,
        admin: 0
      },
      {
        path: '/FindResult',
        name: '查询结果',
        component: FindResult,
        show: 0,
        admin: 0
      },
      {
        path: '/FindResult',
        name: '查询结果',
        component: FindResult,
        show: 0,
        admin: 1
      },
      {
        path: '/Add',
        name: '添加图书',
        component: Add,
        show: 1,
        admin: 1
      },
      {
        path: '/Update',
        name: '修改信息',
        component: Update,
        show: 0,
        admin: 1
      },
      {
        path: '/Delete',
        name: '删除图书',
        component: Delete,
        show: 0,
        admin: 1
      },
      {
        path: '/Find',
        name: '搜索图书',
        component: Find,
        show: 1,
        admin: 0
      },
      {
        path: '/Find',
        name: '搜索图书',
        component: Find,
        show: 1,
        admin: 1
      },
      {
        path: '/Send',
        name: '借还图书',
        component: Send,
        show: 0,
        admin: 0
      },
      {
        path: '/Back',
        name: '借还图书',
        component: Back,
        show: 0,
        admin: 0
      }
    ]
  },
  {
    path: '/Login',
    name: '图书馆登录',
    component: LoginView,
    show: 0,
    admin: 0
  }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
