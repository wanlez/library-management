<template>
  <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm">

    <el-form-item label="图书标识号" prop="isbn">
      <el-input v-model="ruleForm.isbn" readonly></el-input>
    </el-form-item>

    <el-form-item label="图书名称" prop="name">
      <el-input v-model="ruleForm.name" readonly></el-input>
    </el-form-item>

    <el-form-item label="作者" prop="author">
      <el-input v-model="ruleForm.author" readonly></el-input>
    </el-form-item>

    <el-form-item label="库存" prop="amount2">
      <el-input v-model="ruleForm.amount2" readonly></el-input>
    </el-form-item>

    <el-form-item label="数量" prop="verify">
      <el-input v-model="ruleForm.verify"></el-input>
    </el-form-item>

<!--    <el-form-item label="归还数量" prop="verify">-->
<!--      <el-input v-model="ruleForm.verify" readonly></el-input>-->
<!--    </el-form-item>-->

    <el-form-item>
      <el-button type="primary" @click="submitForm('ruleForm')">操作</el-button>
      <el-button @click="goBack('ruleForm')">返回</el-button>
    </el-form-item>
  </el-form>
</template>

<script>


export default {
  data() {
    return {
      revert: '',
      ruleForm: {
        id:'',
        isbn:'',
        name: '',
        author: '',
        amount: '',
        amount2:'',
        verify: '1',
        revert: '',
        account: ''
      },
      rules: {
        // name: [
        //   { required: true, message: '书名不能为空', trigger: 'blur' },
        // ],
        // author: [
        //   { required: true, message: '作者不能为空', trigger: 'change' }
        // ],
        // verify: [
        //   { required: true, message: '数量不能为空且最终数量大于0', trigger: 'change' }
        // ]
      },
    }
  },
  methods: {
    submitForm(formName) {
      let that = this;
      //that.ruleForm.verify = this.data.revert
      //parseInt(that.revert)
      if(that.ruleForm.verify < 0) {
        that.$alert('输入错误', '请输入正值', {
          confirmButtonText: '确定',
          // callback: action => {
          //   return;
          // }
        })
        return;
      }
      if(parseInt(that.ruleForm.amount) + parseInt(that.ruleForm.verify)*parseInt(that.revert) < 0) {
        that.$alert('图书库存不足', '请联系管理员', {
          confirmButtonText: '确定',
          // callback: action => {
          //   return;
          // }
        })
        return;
      }
      that.ruleForm.amount = parseInt(that.ruleForm.amount2) + parseInt(that.ruleForm.verify) * parseInt(that.revert); //如果为借书这是个负值，还书为正值
      that.ruleForm.revert = that.revert;
      this.$refs[formName].validate((valid) => {
        if (valid) {
          axios.post('http://localhost:8181/library/send', this.ruleForm).then(function (resp){
            if(resp.data == 'success') {
                that.$alert('《' + that.ruleForm.name+'》', '借书成功', {
                  confirmButtonText: '确定',
                  callback: action => {
                    that.$router.push({
                      path:'/Query',
                      query: {
                        identity: 0
                      }
                    });
                  }
                });
            }
            else if(resp.data == 'much') {
              that.$alert('数量错误', '归还数量过多', {
                confirmButtonText: '确定',
                callback: action => {
                  // that.$router.push({
                  //   path:'/Query',
                  //   query: {
                  //     identity: 0
                  //   }
                  // });
                }
              });
            }
          })
        } else {
          console.log('error submit!!');
          return false;
        }
      });
    },
    resetForm(formName) {
      this.$refs[formName].resetFields();
    },
    goBack() {
      this.$router.push({
        path:'/Query',
        query: {
          identity: 0
        }
      });
    }
  },
  created() {
    let that = this;
    //alert(that.$route.query.revert)
    that.ruleForm.account = this.$store.state.account
    //alert(that.ruleForm.account)
    axios.get('http://localhost:8181/library/findById/' + that.$route.query.id ).then(function (resp) {
      //alert(resp.data.isbn)
      that.ruleForm.id = resp.data.id,
      that.ruleForm.isbn = resp.data.isbn,
      that.ruleForm.name = resp.data.name,
      that.ruleForm.author = resp.data.author,
      that.ruleForm.amount2= resp.data.amount,
      that.ruleForm.verify = 1
      // that.ruleForm = resp.data,
      // that.ruleForm.verify = 0
    }),
        that.revert = this.$route.query.revert
        //alert(that.revert)
  },
}
</script>

<style scoped>

</style>