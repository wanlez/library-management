<template>
  <div class="login-wrap">
    <div class="ms-login">
      <div class="ms-title">图书管理系统</div>
        <el-form :model="ruleForm" status-icon :rules="rules" ref="ruleForm" label-width="100px" class="ms-content" >
          <el-form-item label="账号" prop="account">
            <el-input v-model="ruleForm.account" ></el-input>
          </el-form-item>
          <el-form-item label="密码" prop="password">
            <el-input type="password" v-model="ruleForm.password" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item class="login-btn" >
            <el-button type="primary" @click="submitForm('ruleForm')">登录</el-button>
          </el-form-item>
          <el-form-item class="login-btn" style="margin-top:-25px">
            <el-button type="primary" @click="submitForm2('ruleForm')">注册</el-button>
          </el-form-item>
          <el-form-item class="login-btn" style="margin-top:-25px">
            <el-button @click="resetForm('ruleForm')">重置</el-button>
          </el-form-item>
        </el-form>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    let checkAccount = (rule, value, callback) => {
      if (value === '') {
        return callback(new Error('账号不能为空'));
      }
      return callback();
      // setTimeout(() => { //这里面添加了if属于规则判断条件，应该是按时显示
      //   if (!Number.isInteger(value)) {
      //     callback(new Error('请输入数字值'));
      //   } else {
      //     if (value < 18) {
      //       callback(new Error('必须年满18岁'));
      //     } else {
      //       callback();
      //     }
      //   }
      // }, 1000);
    };
    let validatePass = (rule, value, callback) => {
      if (value === '') {
        return callback(new Error('请输入密码'));
      }
      return callback();
    };
    // var validatePass2 = (rule, value, callback) => {
    //   if (value === '') {
    //     callback(new Error('请再次输入密码'));
    //   } else if (value !== this.ruleForm.pass) {
    //     callback(new Error('两次输入密码不一致!'));
    //   } else {
    //     callback();
    //   }
    // };
    return {
      ruleForm: {
        password: '',
        account:''
      },
      rules: {
        pass: [
          { validator: validatePass, trigger: 'blur' }
        ],
        account: [
          { validator: checkAccount, trigger: 'blur' }
        ]
        // checkPass: [
        //   { validator: validatePass2, trigger: 'blur' }
        // ],
      }
    };
  },
  methods: {
    setAccount(payload) {
      this.$store.commit('setAccount', payload)
    },
    setIdentity(payload) {
      this.$store.commit('setIdentity', payload)
    },
    submitForm(formName) { //登录,先按账号找密码，再密码相等
      this.$refs[formName].validate((valid) => {
        if (valid) {
          let that = this;
          axios.post('http://localhost:8181/library/login/', this.ruleForm).then(function (resp){
            if(resp.data == 'success_r') {
              // that.$router.push('/');
              that.setAccount(that.ruleForm.account)
              that.setIdentity(1)
              that.$router.push({
                path:'/Query',
                query: {
                  identity: 1,
                  account: that.account
                }
              });
            }
            else if(resp.data == 'success'){
              // that.$router.push('/');
              //alert(that.ruleForm.account)
              that.setAccount(that.ruleForm.account)
              that.setIdentity(0)
              that.$router.push({
                path:'/Query',
                query: {
                  identity: 0,
                  account: that.account
                }
              });
            }
            else {
                that.$alert('账号或密码错误', '登陆失败', {
                confirmButtonText: '确定',
                callback: action => {}
              });
            }
          })
        } else {
          console.log('error submit!!');
          return false;
        }
      });
    },
    submitForm2(formName) { //注册，先按账号找，若账号存在则不行。账号不存在则写入
      this.$refs[formName].validate((valid) => {
        if (valid) {
          let that = this;
          // alert(1)
          //console.log(this.ruleForm)
          axios.post('http://localhost:8181/library/register/', this.ruleForm).then(function (resp){
            if(resp.data == 'success') {
              that.$alert('注册成功', '请登录', {
                confirmButtonText: '确定',
                callback: action => {}
              });
            }
            else {
              that.$alert('账号已注册', '注册失败', {
                confirmButtonText: '确定',
                callback: action => {}
              });
            }
          })
        } else {
          console.log('error register!!');
          return false;
        }
      });
    },
    resetForm(formName) {
      this.$refs[formName].resetFields();
    }
  }
}
</script>

<style>
.login-wrap {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;
  height: 100%;
  background-size: 100% 100%;
}
.ms-title {
  width: 100%;
  line-height: 50px;
  text-align: center;
  font-size: 20px;
  color: black;
  border-bottom: 1px solid #ddd;
}
.ms-login {
  width: 500px;
  border-radius: 5px;
  background: rgba(255, 255, 255, 0.3);
  overflow: hidden;
}

.ms-content {
  padding: 50px 40px;
  background: transparent;
}
.login-btn {
  text-align: center;
}
.login-btn button {
  width: 100%;
  height: 36px;
  margin-bottom: 10px;
}
</style>
