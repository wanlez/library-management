<template>
  <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm">
    <el-form-item label="按书名查找" prop="name">
      <el-input v-model="ruleForm.name"></el-input>
    </el-form-item>

    <el-form-item label="按作者查找" prop="author">
      <el-input v-model="ruleForm.author"></el-input>
    </el-form-item>

    <el-form-item label="按图书标识号查找" prop="isbn">
      <el-input v-model="ruleForm.isbn"></el-input>
    </el-form-item>

    <el-form-item>
      <el-button type="primary" @click="submitForm('ruleForm')">立即查找</el-button>
      <el-button @click="resetForm('ruleForm')">重置</el-button>
    </el-form-item>
  </el-form>
</template>

<script>


export default {
  data() {
    return {
      ruleForm: {
        name: null,
        author: null,
        isbn: null,
      },
      rules: {
        name: [
          { required: false, message: '书名不能为空', trigger: 'blur' },
        ],
        author: [
          { required: false, message: '作者不能为空', trigger: 'change' }
        ],
        amount: [
          { required: false, message: '默认值为1', trigger: 'input' }
        ]
      }
    };
  },
  methods: {
    submitForm(formName) {
      let that = this;
      this.$refs[formName].validate((valid) => {
        if (valid) {
          //alert(that.ruleForm.name+' '+that.ruleForm.author+' '+that.ruleForm.ISBN)
          that.ruleForm.ISBN = parseInt(that.ruleForm.ISBN)
          axios.post('http://localhost:8181/library/findBook', this.ruleForm).then(function (resp){
            if(resp.data != null) {
              that.$router.push({
                path:'/FindResult',
                query: {
                  identity: 0,
                  tableData: resp.data.bookList,
                  total: resp.data.totalElement
                }
              });
            }
            else {
              that.$alert('没有所查图书', '查找失败', {
                confirmButtonText: '确定',
                callback: action => {
                  // that.$router.push('/Query');
                }
              });
            }
          })
        } else {
          console.log('error submit!!');
          return false;
        }
      });
    },
    resetForm(formName) {
      this.$refs[formName].resetFields();
    }
  }
}
</script>

<style>

</style>
