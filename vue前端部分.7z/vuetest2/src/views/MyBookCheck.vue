
<template>
  <div>
    <el-table
        :data="tableData"
        border
        style="width: 100%">
      <el-table-column
          fixed
          prop="show_id"
          label="编号"
          width="150">
      </el-table-column>
      <el-table-column
          prop="name"
          label="书名"
          width="120">
      </el-table-column>
<!--      <el-table-column-->
<!--          prop="author"-->
<!--          label="作者"-->
<!--          width="120">-->
<!--      </el-table-column>-->
      <el-table-column
          prop="isbn"
          label="标识号"
          width="120">
      </el-table-column>
      <el-table-column
          prop="amount"
          label="已借数量"
          width="120">
      </el-table-column>
      <el-table-column
          fixed="right"
          label="操作"
          width="100">
        <template #default="scope">
<!--          <el-button @click="lend(scope.row)" type="text" size="small" v-if="admin == 0">借书</el-button>-->
          <el-button @click="revert(scope.row)" type="text" size="small" v-if="admin == 0">还书</el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-pagination
        layout="prev, pager, next"
        page-size="6"
        :total="total"
        @current-change="page">
    </el-pagination>
  </div>
</template>

<script>
export default {
  methods: {
    revert(row) {
      let that = this;
      this.$router.push({
        path:'/Back',
        query: {
          id: row.id,
          revert: 1
        }
      });
    },
    page(currentPage) {
      let that = this;
      axios.get('http://localhost:8181/library/myFindAll/' + currentPage + '/6/' + that.$store.state.account).then(function (resp){
        that.tableData = resp.data.bookList;
        that.total = resp.data.totalElement;
      })
    }
  },
  // 构造函数
  created(){
    let that = this;
    //alert(this.$store.state.account)
    axios.get('http://localhost:8181/library/myFindAll/1/6/' + this.$store.state.account).then(function (resp){
      that.tableData = resp.data.bookList;
      that.total = resp.data.totalElement;
    }).then(()=>{
      that.tableData.forEach((item, index) => {
        item.show_id = index + 1;
      })
    }),
        that.admin = this.$store.state.account;

  },
  data() {
    return {
      total: null,
      tableData: null,
      admin: 0
    }
  }
}
</script>

<style>

</style>
