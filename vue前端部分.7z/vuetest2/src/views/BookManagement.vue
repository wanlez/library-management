<template>
<!--  app是默认的，app里的route用了index，index里的route用了pageX-->
  <el-container style="height: 500px; border: 1px solid #eee">
    <!--    构建整个页面框架-->
    <el-aside width="200px" style="background-color: rgb(238, 241, 246)">
      <el-menu router :default-openeds="['0', '1']" v-if= "this.admin == 1">
        <el-submenu v-for="(item, index) in $router.options.routes" v-if="(item.show==1) && (item.admin==1)" :index="BookManagement+''">
          <template #title><i class="el-icon-message"></i>{{ item.name }}</template>
<!--          route是浏览器里面的-->
          <el-menu-item v-for="(item2, index2) in item.children" v-if="(item2.show==1) && (item2.admin==1)" :index="item2.path" :class="$route.path==item2.path?'is-active':''">{{ item2.name }}</el-menu-item>
        </el-submenu>
      </el-menu>
      <el-menu router :default-openeds="['0', '1']" v-if= "this.admin == 0">
        <el-submenu v-for="(item, index) in $router.options.routes" v-if="(item.show==1) && (item.admin==1)" :index="BookManagement+''">
          <template #title><i class="el-icon-message"></i>{{ item.name }}</template>
          <!--          route是浏览器里面的-->
          <el-menu-item v-for="(item2, index2) in item.children" v-if="(item2.show==1) && (item2.admin==0)" :index="item2.path" :class="$route.path==item2.path?'is-active':''">{{ item2.name }}</el-menu-item>
        </el-submenu>
      </el-menu>
    </el-aside>
    <el-main>
      <router-view ></router-view>
    </el-main>
  </el-container>
</template>

<script>
export default {
  methods: {

  },
  // 构造函数
  created(){
    let that = this;
    that.admin = that.$store.state.identity;
    that.account = that.$store.state.account
    // that.admin = that.$route.query.identity;
    // that.account = that.$route.query.account
    //alert(that.reader)
  },
  data() {
    return {
      admin: false,
      account: ''
    }
  }
}
</script>

<style scoped>

</style>