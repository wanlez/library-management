
<template>
  <div>
  <el-table
      :data="tableData"
      border
      style="width: 100%">
    <el-table-column
        fixed
        prop="show_id"
        label="编号"
        width="150">
    </el-table-column>
    <el-table-column
        prop="name"
        label="书名"
        width="120">
    </el-table-column>
    <el-table-column
        prop="author"
        label="作者"
        width="120">
    </el-table-column>
    <el-table-column
        prop="isbn"
        label="标识号"
        width="120">
    </el-table-column>
    <el-table-column
        prop="amount"
        label="数量"
        width="120">
    </el-table-column>
    <el-table-column
        fixed="right"
        label="操作"
        width="100">
      <template #default="scope">
        <el-button @click="edit(scope.row)" type="text" size="small" v-if="admin == 1">修改</el-button>
        <el-button @click="deleteBook(scope.row)" type="text" size="small" v-if="admin == 1">删除</el-button>
        <el-button @click="lend(scope.row)" type="text" size="small" v-if="admin == 0">借书</el-button>
        <el-button @click="revert(scope.row)" type="text" size="small" v-if="admin == 0">还书</el-button>
      </template>
    </el-table-column>
  </el-table>
  <el-pagination
      layout="prev, pager, next"
      page-size="6"
      :total="total"
      @current-change="page">
  </el-pagination>
  </div>
</template>

<script>
export default {
  methods: {
    deleteBook(row) {
      // deleteById
      let that = this;
      axios.delete('http://localhost:8181/library/deleteById/' + row.id).then(function (resp) {
        that.$alert('《' + row.name+'》', '删除成功', {
          confirmButtonText: '确定',
          callback: action => {
            // that.$router.push('/Query');
            window.location.reload();
          }
        });
      })
    },
    edit(row) {
      let that = this;
      this.$router.push({
        path:'/Update',
        query: {
          id: row.id
        }
      });
    },
    lend(row) {
      let that = this;
      //alert(row.id)
      this.$router.push({
        path:'/Send',
        query: {
          id: row.id,
          revert: -1
        }
      });
    },
    revert(row) {
      let that = this;
      this.$router.push({
        path:'/Back',
        query: {
          id: row.id,
          revert: 1
        }
      });
    },
    page(currentPage) {
      let that = this;
      axios.get('http://localhost:8181/library/findAll/' + currentPage + '/6').then(function (resp){
        that.tableData = resp.data.bookList;
        that.total = resp.data.totalElement;
      }).then(()=>{
        that.tableData.forEach((item, index) => {
          item.show_id = (currentPage-1) * 6 + index + 1;
        })
      })
    }
  },
  // 构造函数
  created(){
    let that = this;
    axios.get('http://localhost:8181/library/findAll/1/6').then(function (resp){
      //此函数只需两个返回值，content里面是类似[{"id":1,"name":"解忧杂货铺修改版","author":"东野圭吾","isbn":0},
      // {"id":2,"name":"追风筝的人","author":"卡勒德*胡德赛","isbn":1}]，的东西。totalElement是总条数
      //修改接口之后：返回的内容的结构可能与原先有所不同，注意查看返回值
      //console.log(resp);
      that.tableData = resp.data.bookList;
      that.total = resp.data.totalElement;
      // console.log(that.tableData)
      //that.tableData = resp.data.content;
      //that.total = resp.data.totalElements;
    }).then(()=>{
        that.tableData.forEach((item, index) => {
        item.show_id = index + 1;
      })
    })
    //that.admin = that.$route.query.identity;
    that.admin = this.$store.state.identity
    //window.reload();
    //that.ruleForm.account = this.$store.state.account
    //
  },
  data() {
    return {
      total: null,
      tableData: null,
      admin: 0
    }
  }
}
</script>

<style>

</style>
