<template>
  <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm">

    <el-form-item label="图书标识号" prop="isbn">
      <el-input v-model="ruleForm.isbn" readonly></el-input>
    </el-form-item>

    <el-form-item label="图书名称" prop="name">
      <el-input v-model="ruleForm.name"></el-input>
    </el-form-item>

    <el-form-item label="作者" prop="author">
      <el-input v-model="ruleForm.author"></el-input>
    </el-form-item>

    <el-form-item label="已有数量" prop="amount">
      <el-input v-model="ruleForm.amount" readonly></el-input>
    </el-form-item>

    <el-form-item label="变化数量" prop="verify">
      <el-input v-model="ruleForm.verify"></el-input>
    </el-form-item>

    <el-form-item>
      <el-button type="primary" @click="submitForm('ruleForm')">立即修改</el-button>
      <el-button @click="resetForm('ruleForm')">重置</el-button>
    </el-form-item>
  </el-form>
</template>

<script>


export default {
  data() {
    return {
      ruleForm: {
        id:'',
        isbn:'',
        name: '',
        author: '',
        amount: '',
        verify: '0'
      },
      rules: {
        name: [
          { required: true, message: '书名不能为空', trigger: 'blur' },
        ],
        author: [
          { required: true, message: '作者不能为空', trigger: 'change' }
        ],
        verify: [
          { required: true, message: '数量不能为空且最终数量大于0', trigger: 'change' }
        ]
      }
    };
  },
  methods: {
    submitForm(formName) {
      let that = this;
      //alert(1)
      if(parseInt(that.ruleForm.amount) + parseInt(that.ruleForm.verify) <= 0) {
        that.$alert('图书数量不小于1', '重新修改', {
          confirmButtonText: '确定',
          // callback: action => {
          //   return;
          // }
        })
        return;
      }
      that.ruleForm.amount = parseInt(that.ruleForm.amount) + parseInt(that.ruleForm.verify);
      this.$refs[formName].validate((valid) => {
        if (valid) {
          axios.put('http://localhost:8181/library/update', this.ruleForm).then(function (resp){
            if(resp.data == 'success') {
              that.$alert('《' + that.ruleForm.name+'》', '修改成功', {
                confirmButtonText: '确定',
                callback: action => {
                  that.$router.push('/Query');
                }
              });
            }
          })
        } else {
          console.log('error submit!!');
          return false;
        }
      });
    },
    resetForm(formName) {
      this.$refs[formName].resetFields();
    },
  },
  created() {
    let that = this;
    //alert(that.$route.query.id)
    axios.get('http://localhost:8181/library/findById/' + that.$route.query.id ).then(function (resp) {
      //alert(resp.data.isbn)
      that.ruleForm.id = resp.data.id,
      that.ruleForm.isbn = resp.data.isbn,
      that.ruleForm.name = resp.data.name,
      that.ruleForm.author = resp.data.author,
      that.ruleForm.amount = resp.data.amount
      that.ruleForm.verify = 0
      // that.ruleForm = resp.data,
      // that.ruleForm.verify = 0
    })
  },
}
</script>

<style scoped>

</style>