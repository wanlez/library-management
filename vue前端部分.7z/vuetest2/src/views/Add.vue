<template>
  <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm">
    <el-form-item label="图书名称" prop="name">
      <el-input v-model="ruleForm.name"></el-input>
    </el-form-item>

    <el-form-item label="作者" prop="author">
      <el-input v-model="ruleForm.author"></el-input>
    </el-form-item>

    <el-form-item label="添加数量" prop="amount">
      <el-input v-model="ruleForm.amount"></el-input>
    </el-form-item>

    <el-form-item>
      <el-button type="primary" @click="submitForm('ruleForm')">立即创建</el-button>
      <el-button @click="resetForm('ruleForm')">重置</el-button>
    </el-form-item>
  </el-form>
</template>

<script>


export default {
  data() {
    return {
      ruleForm: {
        name: '',
        author: '',
        amount: 1
      },
      rules: {
        name: [
          { required: true, message: '书名不能为空', trigger: 'blur' },
        ],
        author: [
          { required: true, message: '作者不能为空', trigger: 'change' }
        ],
        amount: [
          { required: true, message: '默认值为1', trigger: 'input' }
        ]
      }
    };
  },
  methods: {
    submitForm(formName) {
      let that = this;
      if(that.ruleForm.amount <= 0) {
        that.$alert('数量不小于1', '重新添加', {
          confirmButtonText: '确定',
          // callback: action => {
          //   return;
          // }
        })
        return;
      }
      this.$refs[formName].validate((valid) => {
        if (valid) {
          axios.post('http://localhost:8181/library/save', this.ruleForm).then(function (resp){
            if(resp.data == 'success') {
              that.$alert('《' + that.ruleForm.name+'》', '添加成功', {
                confirmButtonText: '确定',
                callback: action => {
                  that.$router.push('/Query');
                }
              });
            }
          })
        } else {
          console.log('error submit!!');
          return false;
        }
      });
    },
    resetForm(formName) {
      this.$refs[formName].resetFields();
    }
  }
}
</script>

<style>

</style>
