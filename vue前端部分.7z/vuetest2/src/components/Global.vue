<template>

</template>

<script>
// const account = ''
export default {
  name: "Global"
}
</script>

<style scoped>

</style>