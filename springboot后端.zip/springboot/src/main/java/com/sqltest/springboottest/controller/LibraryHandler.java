package com.sqltest.springboottest.controller;

import com.sqltest.springboottest.entity.*;
import com.sqltest.springboottest.dao.LibraryDao;
import com.sqltest.springboottest.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import com.sqltest.springboottest.service.ReaderService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.*;
import com.sqltest.springboottest.dao.BookDao;
import com.sqltest.springboottest.service.LogService;

import java.util.ArrayList;
//Java框架中entity(model)层  mapper层                   service层                     controller层
//       实体层定义类        数据库控制层 通过mapper和model(entity)为controller提供调用的函数  web层交互
// 这个项目只有controller层，service是repository，dao层被jpa代替
// 在MVC架构体系中，view-controller-model，在三层体系中controller-service-dao，其中MVC的VC被整合为controller，
// 而model层被分为数据承载bean（entity）和数据处理bean（包括Service和dao），传统意义上的model层变为只指代entity
// controller-service-mapper(dao)
//现在可以确认的是controller只调用service写好的服务，而service调用mapper的数据库交互

@RestController
@RequestMapping("/library")

public class LibraryHandler {
    @Autowired
    private LibraryDao LibraryDao;
    @Autowired
    private BookService bookService;
    @Autowired
    private LogService logService;
    @Autowired
    private ReaderService readerService;

    @GetMapping("/findAll/{page}/{size}")
    public IPage findAll(@PathVariable("page") Integer page, @PathVariable("size") Integer size) {
        //新的查询方法 需要返回的是一个类，类里包括一个存有所有数据各项的数组和总数据条数
        //调用service层的方法
        return bookService.findPage(page-1, size);
    }

    @GetMapping("/myFindAll/{page}/{size}/{account}")
    public IPage myFindAll(@PathVariable("page") Integer page, @PathVariable("size") Integer size, @PathVariable("account") String account) {
        //新的查询方法 需要返回的是一个类，类里包括一个存有所有数据各项的数组和总数据条数
        //调用service层的方法
        return readerService.findPage(page-1, size, account);
    }

    @PostMapping("/findBook")
    public IPage findBook(@RequestBody Book book) {
        //System.out.println(book.getIsbn());
        //name author ISBN
        return bookService.findBook(book);
    }
//    public Page<Library> findAll(@PathVariable("page") Integer page, @PathVariable("size") Integer size) {
//        //新的查询方法 需要返回的是一个类，类里包括一个存有所有数据各项的数组和总数据条数
//        //return libraryRepository.findAll(page-1, size);
//        Pageable pageable = PageRequest.of(page-1, size);
//        return LibraryDao.findAll(pageable);
//    }

    @PostMapping("/save")
    public String save(@RequestBody Book book) {
        Book result = bookService.save(book);
        if(result != null) {
            return "success";
        }
        else {
            return "error";
        }
    }

    @PostMapping("/login")
    public String login(@RequestBody LogPacket logpacket) {
        LogPacket result = logService.login(logpacket);
        if(result != null) {
            if(result.getAuthority() == 1) {
                return "success_r";
            }
            else {
                return "success";
            }
        }
        else {
            return "error";
        }
    }
    @PostMapping("/register")
    public String register(@RequestBody LogPacket logpacket) {
        //System.out.println(logpacket.getPassword());
        LogPacket result = logService.register(logpacket);
        //System.out.println(result.getPassword());
        if(result != null) {
            return "success";
        }
        else {
            return "error";
        }
    }
//    public String save(@RequestBody Library library) {
//        Library result = LibraryDao.save(library);
//        if(result != null) {
//            return "success";
//        }
//        else {
//            return "error";
//        }
//    }

    @GetMapping("/findById/{id}")
//    public Library findById(@PathVariable("id") Integer id) {
//        return LibraryDao.findById(id).get();
//    }
    public Book findById(@PathVariable("id") Integer id) {
        return bookService.findById(id);
    }

    @PutMapping("/update") //update:对某本书进行具体操作，比如修改他的数量和名字。
    public String update(@RequestBody Book book) {
        Book result = bookService.update(book);
        if(result != null) {
            return "success";
        }
        else {
            return "error";
        }
    }
    @PostMapping("/send")
    public String Send(@RequestBody SendPacket sendpacket) {
        //System.out.println(sendpacket.getRevert());
        //返回null是错误，返回sendpacket看ifBorrow
        SendPacket result; //这玩意没有实体，就类似指针
        //System.out.println(sendpacket.getVerify());
        if(sendpacket.getRevert() == 1) {//还书
            result = readerService.returnBook(sendpacket);
        }
        else {
            result = readerService.borrowBook(sendpacket);
        }
        if(result != null) {
            if(result.getIfBorrow() == 1) return "success";
            else return "much";
        }
        else {
            return "error";
        }
    }
//    public String update(@RequestBody Library library) {
//        Library result = LibraryDao.save(library);
//        if(result != null) {
//            return "success";
//        }
//        else {
//            return "error";
//        }
//    }

    @GetMapping("/getBorrow/{account}/{name}") //通过account/name获得amount，其实就findAandB
    public Integer getBorrow(@PathVariable("account") String account, @PathVariable("name") String name) {
        SendPacket sendpacket = new SendPacket();
        sendpacket.setAccount(account);
        sendpacket.setName(name);
        return readerService.getBorrow(sendpacket);
    }

    @DeleteMapping("/deleteById/{id}")
    public void deleteById(@PathVariable("id") Integer id) {
        bookService.deleteById(id);
    }
//    public void deleteById(@PathVariable("id") Integer id) {
//        LibraryDao.deleteById(id);
//    }
}
