package com.sqltest.springboottest.entity;

import lombok.Data;

import java.util.ArrayList;

@Data
public class IPage {
    private ArrayList<Book> bookList;
    private int totalElement;
}
