package com.sqltest.springboottest.entity;

import lombok.Data;

@Data
public class LogPacket {
    private String account;
    private String password;
    private Integer Authority;
}
