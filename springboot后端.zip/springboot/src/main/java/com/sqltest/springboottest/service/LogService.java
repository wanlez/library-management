package com.sqltest.springboottest.service;

import com.sqltest.springboottest.dao.BookDao;
import com.sqltest.springboottest.entity.LogPacket;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.sqltest.springboottest.dao.LogDao;

@Component
public class LogService {
    @Autowired
    private LogDao logDao;
    public LogPacket login(LogPacket logpacket) {
        //找账号，和密码比较。账号不存在或密码不对就返回否
        LogPacket result = logDao.findAccount(logpacket);
        if(result == null) {
            return null;
        }
        else { //返回的密码等于输入的密码
            if (result.getPassword().equals(logpacket.getPassword())) {
                //System.out.println("s" + result.getAuthority());
                return result;
            }
            else return null;
        }
    }

    public LogPacket register(LogPacket logpacket) {
        //找账号,没账号就存入
        LogPacket exist = logDao.findAccount(logpacket);
        if(exist == null) {
            logDao.save(logpacket);
            return logpacket;
        }
        else return null;
    }
}
