package com.sqltest.springboottest.dao;
import com.sqltest.springboottest.entity.Book;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;
import com.sqltest.springboottest.entity.IPage;

import java.util.ArrayList;


// Page<library> LibraryDao.findAll(pageable)
// library result = LibraryDao.save(library)
// findById() findById(@PathVariable("id") Integer id).(get)
//update : library result = LibraryDao.save(library);
// LibraryDao.deleteById(id)

@Component
public interface BookDao  {
    //这里应该是返回一个类数组，在上层继续处理，把totalelement算出来
    ArrayList<Book> findAll(Integer page, Integer size);

    Integer findTotalElem();

    Book save(Book book);

    Book findById(Integer id); //get()只是用于检查

    Book update(Book book);//update的id不为空，而save的id为空

    void deleteById(Integer id);

    Integer findGap();

    ArrayList<Book> findBook(Book book);

    ArrayList<Book> findBook(String name, String author);

    ArrayList<Book> findBook(String name, Integer ISBN);

    ArrayList<Book> findBook(String author, Integer ISBN, boolean type); //加个true

    ArrayList<Book> findBook(String name);

    ArrayList<Book> findBook(String author,  boolean type);

    ArrayList<Book> findBook(Integer ISBN);
}
