package com.sqltest.springboottest.service;

import com.sqltest.springboottest.dao.BookDao;
import com.sqltest.springboottest.dao.ReaderDao;
import com.sqltest.springboottest.entity.Book;
import com.sqltest.springboottest.entity.IPage;
import com.sqltest.springboottest.entity.SendPacket;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import java.util.Iterator;

@Component
public class ReaderService {
    @Autowired
    private BookDao bookDao;
    @Autowired
    private NumOpera numOp;
    @Autowired
    private ReaderDao readerDao;

    public IPage findPage(Integer page, Integer size, String account) { //让它调用dao层
        IPage pageI = new IPage();
        Integer base = page * size;
        pageI.setBookList(readerDao.findAll(base, size, account));
        //返回了一串booklist，按道理应该拿着书名去library查相关信息

//        for(Iterator<Book> it=pageI.getBookList().iterator(); it.hasNext();) {
//
//        }
        //再通过PageI的list长度设置totalElement
        pageI.setTotalElement(readerDao.findTotalElem(account));
//        return pageI;
        return pageI;
    }

    public SendPacket borrowBook(SendPacket sendpacket) {
        SendPacket sendpacket1 = readerDao.findAandB(sendpacket); //只有amount name account
        //System.out.println(sendpacket1.getAmount() + ' '+ sendpacket1.getName() + ' ' + sendpacket1.getAccount());
        //首次借还是再次借
        if(sendpacket1 != null) {//曾经借过，只改数量update
            sendpacket.setVerify(sendpacket1.getAmount() + sendpacket.getVerify());
            readerDao.update(sendpacket);
        }
        else {//首次借书记录，插入readerDao.save(sendpacket);
            readerDao.save(sendpacket);
        }
        Book book = new Book();
        System.out.println(sendpacket.getAmount());
        book.setAmount(sendpacket.getAmount()); //getAmount一直是书库中数量，其实应该先取 9 1
        book.setName(sendpacket.getName());
        book.setAuthor(sendpacket.getAuthor());
        book.setId(sendpacket.getId());
        book.setIsbn(sendpacket.getIsbn());
        sendpacket.setIfBorrow(1);
        if(bookDao.update(book) != null) return sendpacket;
        return null;
    }

    public SendPacket returnBook(SendPacket sendpacket) {
        SendPacket sendpacket1 = readerDao.findAandB(sendpacket); //只有数量
        if(sendpacket1 != null) {//再次只改数量update
            if(sendpacket1.getAmount() < sendpacket.getVerify()) { //还太多了
                sendpacket.setIfBorrow(0);
                return sendpacket;
            }
            else if(sendpacket1.getAmount() == sendpacket.getVerify()) {//如果发现还完之后为0，还要把记录删掉
                readerDao.delete(sendpacket);
            }
            else {
                sendpacket.setVerify(sendpacket1.getAmount() - sendpacket.getVerify());
                readerDao.update(sendpacket);
            }
        }
        else {//没这次记录，不能归还
            sendpacket.setIfBorrow(0);
            return sendpacket;
        }
        Book book = new Book();
        System.out.println(sendpacket.getAmount());
        book.setAmount(sendpacket.getAmount());
        book.setName(sendpacket.getName());
        book.setAuthor(sendpacket.getAuthor());
        book.setId(sendpacket.getId());
        book.setIsbn(sendpacket.getIsbn());
        sendpacket.setIfBorrow(1);
        if(bookDao.update(book) != null) return sendpacket;
        return null;
    }

    public Integer getBorrow(SendPacket sendpacket) {
        SendPacket sendpacket1 = readerDao.findAandB(sendpacket);
        if(sendpacket1 != null) {
            Integer i = readerDao.findAandB(sendpacket).getAmount();
            if(i == null) return 0;
            else return i;
        }
        //System.out.println(i);
        return 0;
    }
}
