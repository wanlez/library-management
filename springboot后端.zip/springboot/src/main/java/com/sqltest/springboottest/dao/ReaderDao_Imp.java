package com.sqltest.springboottest.dao;

import com.sqltest.springboottest.entity.Book;
import com.sqltest.springboottest.entity.SendPacket;
import com.sqltest.springboottest.util.JdbcUtil;
import org.springframework.stereotype.Component;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

@Component
public class ReaderDao_Imp implements ReaderDao {
    @Override
    public Integer findTotalElem(String account) {
        //获取数据库连接
        Connection connection = JdbcUtil.getConnection();
        try {
            //需要执行的sql语句
            String sql = "select count(*) from reader where account = ?";
            //获取预处理对象，并给参数赋值
            PreparedStatement statement = connection.prepareCall(sql);
            statement.setString(1, account);
            ResultSet result = statement.executeQuery();
            if(result.next()) {
                return result.getInt(1);
            }
            //关闭jdbc连接
            statement.close();
            connection.close();
            return 0;
        }
        catch (SQLException ClassNotFoundException) {
            ClassNotFoundException.printStackTrace();
            return 0;
        }
    }

    @Override
    public ArrayList<Book> findAll(Integer page, Integer size, String account) {
        ArrayList<Book> bookList = new ArrayList<Book>();
        //获取数据库连接
        Connection connection = JdbcUtil.getConnection();
        try {
            //需要执行的sql语句
            String sql = "select * from reader where account = ? limit ?, ?";
            //获取预处理对象，并给参数赋值
            PreparedStatement statement = connection.prepareCall(sql);
            statement.setInt(2, page);
            statement.setInt(3, size);
            statement.setString(1, account);
            //执行sql语句（插入了几条记录，就返回几）
            ResultSet result = statement.executeQuery();  //executeUpdate：执行并更新
            while(result.next()) {
                Book book = new Book();
                //book.setId(result.getInt("id"));
                book.setName(result.getString("book"));
                //book.setAuthor(result.getString("author"));
                book.setIsbn(result.getInt("ISBN"));
                book.setAmount(result.getInt("number"));
                book.setId(result.getInt("ID"));
                bookList.add(book);
            }
//            String sql2 = "select count(*) from library";
//            result = statement.executeQuery();
//            if(result.next()) {
//                pageI.setTotalElement(result.getInt(1));
//            }
            //关闭jdbc连接
            statement.close();
            connection.close();
            return bookList;
        }
        catch (SQLException ClassNotFoundException) {
            ClassNotFoundException.printStackTrace();
            return null;
        }
    }
    @Override
    public SendPacket save(SendPacket sendpacket) {
        //获取数据库连接
        Connection connection = JdbcUtil.getConnection();
        //System.out.println(sendpacket.getName());
        //System.out.println(sendpacket.getAccount());
        try {
            //需要执行的sql语句
            String sql = "insert into reader(account, book,  number, ID, ISBN) values(?,?,?,?,?)";
            //获取预处理对象，并给参数赋值
            PreparedStatement statement = connection.prepareCall(sql);
            //statement.setInt(1,14);
            statement.setString(1, sendpacket.getAccount());
            statement.setString(2,sendpacket.getName());
            statement.setInt(3,sendpacket.getVerify());
            statement.setInt(4,sendpacket.getId());
            statement.setInt(5,sendpacket.getIsbn());
            //statement.setString(6, sendpacket.getAuthor());
            //statement.setInt(5,);
            //执行sql语句（插入了几条记录，就返回几）
            int i = statement.executeUpdate();  //executeUpdate：执行并更新
            //System.out.println(i);
            //关闭jdbc连接
            statement.close();
            connection.close();
            return sendpacket;
        }
        catch (SQLException ClassNotFoundException) {
            ClassNotFoundException.printStackTrace();
            return null;
        }
    }

    @Override
    public SendPacket findAandB(SendPacket sendpacket) {
        //获取数据库连接
        Connection connection = JdbcUtil.getConnection();
        try {
            //需要执行的sql语句
            String sql = "select * from reader where book = ? and account = ?";
            //获取预处理对象，并给参数赋值
            PreparedStatement statement = connection.prepareCall(sql);
            statement.setString(1, sendpacket.getName());
            statement.setString(2, sendpacket.getAccount());
            //执行sql语句（插入了几条记录，就返回几）
            ResultSet result = statement.executeQuery();  //executeUpdate：执行并更新
            if(result.next()) {
                SendPacket sendpacket1 = new SendPacket();
                sendpacket1.setAmount(result.getInt("number")); //只获取数量
                sendpacket1.setName(sendpacket.getName());
                sendpacket1.setAccount(sendpacket.getAccount());
                //关闭jdbc连接
                statement.close();
                connection.close();
                return sendpacket1;
            }
//            String sql2 = "select count(*) from library";
//            result = statement.executeQuery();
//            if(result.next()) {
//                pageI.setTotalElement(result.getInt(1));
//            }
            //关闭jdbc连接
            statement.close();
            connection.close();
            return null;
        }
        catch (SQLException ClassNotFoundException) {
            ClassNotFoundException.printStackTrace();
            return null;
        }
    }

    @Override
    public void delete(SendPacket sendpacket) {
        //获取数据库连接
        Connection connection = JdbcUtil.getConnection();
        try {
            //需要执行的sql语句
            String sql = "delete from reader where account = ? and book = ?";
            //获取预处理对象，并给参数赋值
            PreparedStatement statement = connection.prepareCall(sql);
            statement.setString(1, sendpacket.getAccount());
            statement.setString(2, sendpacket.getName());
            //执行sql语句（插入了几条记录，就返回几）
            int i = statement.executeUpdate();  //executeUpdate：执行并更新
            //System.out.println(i);
            //关闭jdbc连接
            statement.close();
            connection.close();
        }
        catch (SQLException ClassNotFoundException) {
            ClassNotFoundException.printStackTrace();
        }
    }

    @Override
    public SendPacket update(SendPacket sendpacket) {
        //获取数据库连接
        Connection connection = JdbcUtil.getConnection();
        try {
            //需要执行的sql语句
            String sql = "update reader set number = ? where book = ? and account = ?";
            //获取预处理对象，并给参数赋值
            PreparedStatement statement = connection.prepareCall(sql);
            statement.setInt(1, sendpacket.getVerify());
            statement.setString(2, sendpacket.getName());
            statement.setString(3, sendpacket.getAccount());
            //执行sql语句（插入了几条记录，就返回几）
            int i = statement.executeUpdate();  //executeUpdate：执行并更新
            //关闭jdbc连接
            statement.close();
            connection.close();
            return sendpacket;
        }
        catch (SQLException ClassNotFoundException) {
            ClassNotFoundException.printStackTrace();
            return null;
        }
    }
}
