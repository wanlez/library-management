package com.sqltest.springboottest.dao;

import com.sqltest.springboottest.entity.Library;
import org.springframework.data.jpa.repository.JpaRepository;

//service层，相当于dao层已经由jpa已经写好了。一般dao层下会有一个xml文件，文件内容是SQL语句
public interface LibraryDao extends JpaRepository<Library, Integer> {

}


//public interface ifindAll() {
//
//}

