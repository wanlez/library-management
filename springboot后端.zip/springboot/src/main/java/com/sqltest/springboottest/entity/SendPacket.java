package com.sqltest.springboottest.entity;

import lombok.Data;

@Data
public class SendPacket {
    private Integer id;
    private String name;
    private String author;
    private Integer isbn;
    private Integer amount;
    private Integer revert; //1是还书，-1是借书
    private String account; //谁借的书
    private Integer verify;
    private Integer ifBorrow;
}
