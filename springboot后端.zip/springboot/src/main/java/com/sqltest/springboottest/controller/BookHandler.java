package com.sqltest.springboottest.controller;

import com.sqltest.springboottest.dao.BookDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/book")
public class BookHandler {
    //@Autowired
    //private BookDao bookDao;


}
