package com.sqltest.springboottest.dao;

import com.sqltest.springboottest.entity.Book;
import com.sqltest.springboottest.entity.SendPacket;
import org.springframework.stereotype.Component;

import java.util.ArrayList;

@Component
public interface ReaderDao {
    ArrayList<Book> findAll(Integer page, Integer size, String account);

    Integer findTotalElem(String account);

    SendPacket save(SendPacket sendpacket);

    SendPacket findAandB(SendPacket sendpacket);

    SendPacket update(SendPacket sendpacket);

    void delete(SendPacket sendpacket);
}
