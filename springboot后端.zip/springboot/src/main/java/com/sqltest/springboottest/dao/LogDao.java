package com.sqltest.springboottest.dao;

import com.sqltest.springboottest.entity.LogPacket;
import org.springframework.stereotype.Component;

import java.util.logging.LoggingPermission;

@Component
public interface LogDao {
    LogPacket findAccount(LogPacket logpacket);

    LogPacket save(LogPacket logpacket);
}
