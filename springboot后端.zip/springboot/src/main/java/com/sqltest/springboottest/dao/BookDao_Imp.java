package com.sqltest.springboottest.dao;

import com.sqltest.springboottest.entity.Book;
import com.sqltest.springboottest.entity.IPage;
import com.sqltest.springboottest.util.JdbcUtil;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;

import java.sql.*;

@Component
public class BookDao_Imp implements BookDao{
    @Override
    public Integer findTotalElem() {
        //获取数据库连接
        Connection connection = JdbcUtil.getConnection();
        try {
            //需要执行的sql语句
            String sql = "select count(*) from library";
            //获取预处理对象，并给参数赋值
            PreparedStatement statement = connection.prepareCall(sql);
            ResultSet result = statement.executeQuery();
            if(result.next()) {
                return result.getInt(1);
            }
            //关闭jdbc连接
            statement.close();
            connection.close();
            return 0;
        }
        catch (SQLException ClassNotFoundException) {
            ClassNotFoundException.printStackTrace();
            return 0;
        }
    }

    @Override
    public ArrayList<Book> findAll(Integer page, Integer size) {
        ArrayList<Book> bookList = new ArrayList<Book>();
        //获取数据库连接
        Connection connection = JdbcUtil.getConnection();
        try {
            //需要执行的sql语句
            String sql = "select * from library limit ?, ?";
            //获取预处理对象，并给参数赋值
            PreparedStatement statement = connection.prepareCall(sql);
            statement.setInt(1, page);
            statement.setInt(2, size);
            //执行sql语句（插入了几条记录，就返回几）
            ResultSet result = statement.executeQuery();  //executeUpdate：执行并更新
            while(result.next()) {
                Book book = new Book();
                book.setId(result.getInt("id"));
                book.setName(result.getString("name"));
                book.setAuthor(result.getString("author"));
                book.setIsbn(result.getInt("ISBN"));
                book.setAmount(result.getInt("amount"));
                bookList.add(book);
            }
//            String sql2 = "select count(*) from library";
//            result = statement.executeQuery();
//            if(result.next()) {
//                pageI.setTotalElement(result.getInt(1));
//            }
            //关闭jdbc连接
            statement.close();
            connection.close();
            return bookList;
        }
        catch (SQLException ClassNotFoundException) {
            ClassNotFoundException.printStackTrace();
            return null;
        }
    }

    @Override
    public Book save(Book book) {
        //获取数据库连接
        Connection connection = JdbcUtil.getConnection();
        try {
            //需要执行的sql语句
            String sql = "insert into library(name, author, ISBN, amount) values(?,?,?,?)";
            //获取预处理对象，并给参数赋值
            PreparedStatement statement = connection.prepareCall(sql);
            //statement.setInt(1,14);
            statement.setString(1, book.getName());
            statement.setString(2,book.getAuthor());
            statement.setInt(3,book.getIsbn());
            statement.setInt(4,book.getAmount());
            //执行sql语句（插入了几条记录，就返回几）
            int i = statement.executeUpdate();  //executeUpdate：执行并更新
            //System.out.println(i);
            //关闭jdbc连接
            statement.close();
            connection.close();
            return book;
        }
        catch (SQLException ClassNotFoundException) {
            ClassNotFoundException.printStackTrace();
            return null;
        }
    }

//    @Override
    public Book findById(Integer id) { //get()只是用于检查
        Book book = new Book();

        //获取数据库连接
        Connection connection = JdbcUtil.getConnection();
        try {
            //需要执行的sql语句
            String sql = "select * from library where id = ?";
            //获取预处理对象，并给参数赋值
            PreparedStatement statement = connection.prepareCall(sql);
            statement.setInt(1, id);
            //执行sql语句（插入了几条记录，就返回几）
            ResultSet result = statement.executeQuery();  //executeUpdate：执行并更新
            while(result.next()) {
                book.setId(result.getInt("id"));
                book.setName(result.getString("name"));
                book.setAuthor(result.getString("author"));
                book.setIsbn(result.getInt("ISBN"));
                book.setAmount(result.getInt("amount"));
            }
            //关闭jdbc连接
            statement.close();
            connection.close();
            return book;
        }
        catch (SQLException ClassNotFoundException) {
            ClassNotFoundException.printStackTrace();
            return null;
        }
    }

    @Override
    public Book update(Book book) { //update的id不为空，而save的id为空

        //获取数据库连接
        Connection connection = JdbcUtil.getConnection();
        try {
            //需要执行的sql语句
            String sql = "update library set name = ?, author = ?, amount = ? where id = ?";
            //获取预处理对象，并给参数赋值
            PreparedStatement statement = connection.prepareCall(sql);
            //statement.setInt(1,14);
            statement.setString(1, book.getName());
            statement.setString(2, book.getAuthor());
            statement.setInt(3, book.getAmount());
            statement.setInt(4, book.getId());
            //执行sql语句（插入了几条记录，就返回几）
            int i = statement.executeUpdate();  //executeUpdate：执行并更新
            //System.out.println(i);
            //关闭jdbc连接
            statement.close();
            connection.close();
            return book;
        }
        catch (SQLException ClassNotFoundException) {
            ClassNotFoundException.printStackTrace();
            return null;
        }

    }

    @Override
    public void deleteById(Integer id) {
        //获取数据库连接
        Connection connection = JdbcUtil.getConnection();
        try {
            //需要执行的sql语句
            String sql = "delete from library where id = ?";
            //获取预处理对象，并给参数赋值
            PreparedStatement statement = connection.prepareCall(sql);
            statement.setInt(1, id);
            //执行sql语句（插入了几条记录，就返回几）
            int i = statement.executeUpdate();  //executeUpdate：执行并更新
            //System.out.println(i);
            //关闭jdbc连接
            statement.close();
            connection.close();
        }
        catch (SQLException ClassNotFoundException) {
            ClassNotFoundException.printStackTrace();
        }
    }

    @Override
    public Integer findGap() {
        //获取数据库连接
        Connection connection = JdbcUtil.getConnection();
        try {
            //需要执行的sql语句
            String sql = "select min(ISBN) from (select ISBN from library order by ISBN asc) t where not exists (select 1 from library \n" +
                    " where ISBN=t.ISBN-1)";
            //获取预处理对象，并给参数赋值
            PreparedStatement statement = connection.prepareCall(sql);
            //执行sql语句 断号查询
            ResultSet result = statement.executeQuery();
            if(result.next()) {
                return result.getInt(1);
            }
            //关闭jdbc连接
            statement.close();
            connection.close();
            return 0;
        }
        catch (SQLException ClassNotFoundException) {
            ClassNotFoundException.printStackTrace();
            return null;
        }
    }
    @Override
    public ArrayList<Book> findBook(Book book) {
        ArrayList<Book> bookList = new ArrayList<Book>();
        //获取数据库连接
        Connection connection = JdbcUtil.getConnection();
        try {
            //需要执行的sql语句
            String sql = "select * from library where name = and author = and ISBN = ?";
            //获取预处理对象，并给参数赋值
            PreparedStatement statement = connection.prepareCall(sql);
            statement.setString(1, book.getName());
            statement.setString(2, book.getAuthor());
            statement.setInt(3, book.getIsbn());
            //执行sql语句（插入了几条记录，就返回几）
            ResultSet result = statement.executeQuery();  //executeUpdate：执行并更新
            while(result.next()) {
                Book book1 = new Book();
                book1.setId(result.getInt("id"));
                book1.setName(result.getString("name"));
                book1.setAuthor(result.getString("author"));
                book1.setIsbn(result.getInt("ISBN"));
                book1.setAmount(result.getInt("amount"));
                bookList.add(book1);
            }
            //关闭jdbc连接
            statement.close();
            connection.close();
            return bookList;
        }
        catch (SQLException ClassNotFoundException) {
            ClassNotFoundException.printStackTrace();
            return null;
        }
    }

    @Override
    public ArrayList<Book> findBook(String name, String author) {
        ArrayList<Book> bookList = new ArrayList<Book>();
        //获取数据库连接
        Connection connection = JdbcUtil.getConnection();
        try {
            //需要执行的sql语句
            String sql = "select * from library where name = ? and author = ?";
            //获取预处理对象，并给参数赋值
            PreparedStatement statement = connection.prepareCall(sql);
            statement.setString(1, name);
            statement.setString(2, author);
            //执行sql语句（插入了几条记录，就返回几）
            ResultSet result = statement.executeQuery();  //executeUpdate：执行并更新
            while(result.next()) {
                Book book = new Book();
                book.setId(result.getInt("id"));
                book.setName(result.getString("name"));
                book.setAuthor(result.getString("author"));
                book.setIsbn(result.getInt("ISBN"));
                book.setAmount(result.getInt("amount"));
                bookList.add(book);
            }
            //关闭jdbc连接
            statement.close();
            connection.close();
            return bookList;
        }
        catch (SQLException ClassNotFoundException) {
            ClassNotFoundException.printStackTrace();
            return null;
        }

    }

    @Override
    public ArrayList<Book> findBook(String name, Integer ISBN) {
        //System.out.println(123);
        ArrayList<Book> bookList = new ArrayList<Book>();
        //获取数据库连接
        Connection connection = JdbcUtil.getConnection();
        try {
            //需要执行的sql语句
            String sql = "select * from library where name = ? and ISBN = ?";
            //获取预处理对象，并给参数赋值
            PreparedStatement statement = connection.prepareCall(sql);
            statement.setString(1, name);
            statement.setInt(2, ISBN);
            //执行sql语句（插入了几条记录，就返回几）
            ResultSet result = statement.executeQuery();  //executeUpdate：执行并更新
            while(result.next()) {
                Book book = new Book();
                book.setId(result.getInt("id"));
                book.setName(result.getString("name"));
                book.setAuthor(result.getString("author"));
                book.setIsbn(result.getInt("ISBN"));
                book.setAmount(result.getInt("amount"));
                bookList.add(book);
            }
            //关闭jdbc连接
            statement.close();
            connection.close();
            return bookList;
        }
        catch (SQLException ClassNotFoundException) {
            ClassNotFoundException.printStackTrace();
            return null;
        }

    }

    @Override
    public ArrayList<Book> findBook(String author, Integer ISBN, boolean type) {
        ArrayList<Book> bookList = new ArrayList<Book>();
        //获取数据库连接
        Connection connection = JdbcUtil.getConnection();
        try {
            //需要执行的sql语句
            String sql = "select * from library where author = ? and ISBN = ?";
            //获取预处理对象，并给参数赋值
            PreparedStatement statement = connection.prepareCall(sql);
            statement.setString(1, author);
            statement.setInt(2, ISBN);
            //执行sql语句（插入了几条记录，就返回几）
            ResultSet result = statement.executeQuery();  //executeUpdate：执行并更新
            while(result.next()) {
                Book book = new Book();
                book.setId(result.getInt("id"));
                book.setName(result.getString("name"));
                book.setAuthor(result.getString("author"));
                book.setIsbn(result.getInt("ISBN"));
                book.setAmount(result.getInt("amount"));
                bookList.add(book);
            }
            //关闭jdbc连接
            statement.close();
            connection.close();
            return bookList;
        }
        catch (SQLException ClassNotFoundException) {
            ClassNotFoundException.printStackTrace();
            return null;
        }
    }

    @Override
    public ArrayList<Book> findBook(String name) {
        //System.out.println(321);
        ArrayList<Book> bookList = new ArrayList<Book>();
        //获取数据库连接
        Connection connection = JdbcUtil.getConnection();
        try {
            //需要执行的sql语句
            String sql = "select * from library where name = ?";
            //获取预处理对象，并给参数赋值
            PreparedStatement statement = connection.prepareCall(sql);
            statement.setString(1, name);
            //执行sql语句（插入了几条记录，就返回几）
            ResultSet result = statement.executeQuery();  //executeUpdate：执行并更新
            while(result.next()) {
                Book book = new Book();
                book.setId(result.getInt("id"));
                book.setName(result.getString("name"));
                book.setAuthor(result.getString("author"));
                book.setIsbn(result.getInt("ISBN"));
                book.setAmount(result.getInt("amount"));
                bookList.add(book);
            }
            //关闭jdbc连接
            statement.close();
            connection.close();
            return bookList;
        }
        catch (SQLException ClassNotFoundException) {
            ClassNotFoundException.printStackTrace();
            return null;
        }
    }

    @Override
    public ArrayList<Book> findBook(String author,  boolean type) {
        ArrayList<Book> bookList = new ArrayList<Book>();
        //获取数据库连接
        Connection connection = JdbcUtil.getConnection();
        try {
            //需要执行的sql语句
            String sql = "select * from library where author = ?";
            //获取预处理对象，并给参数赋值
            PreparedStatement statement = connection.prepareCall(sql);
            statement.setString(1, author);
            //执行sql语句（插入了几条记录，就返回几）
            ResultSet result = statement.executeQuery();  //executeUpdate：执行并更新
            while(result.next()) {
                Book book = new Book();
                book.setId(result.getInt("id"));
                book.setName(result.getString("name"));
                book.setAuthor(result.getString("author"));
                book.setIsbn(result.getInt("ISBN"));
                book.setAmount(result.getInt("amount"));
                bookList.add(book);
            }
            //关闭jdbc连接
            statement.close();
            connection.close();
            return bookList;
        }
        catch (SQLException ClassNotFoundException) {
            ClassNotFoundException.printStackTrace();
            return null;
        }

    }

    @Override
    public ArrayList<Book> findBook(Integer ISBN) {
        ArrayList<Book> bookList = new ArrayList<Book>();
        //获取数据库连接
        Connection connection = JdbcUtil.getConnection();
        try {
            //需要执行的sql语句
            String sql = "select * from library where ISBN = ?";
            //获取预处理对象，并给参数赋值
            PreparedStatement statement = connection.prepareCall(sql);
            statement.setInt(1, ISBN);
            //执行sql语句（插入了几条记录，就返回几）
            ResultSet result = statement.executeQuery();  //executeUpdate：执行并更新
            while(result.next()) {
                Book book = new Book();
                book.setId(result.getInt("id"));
                book.setName(result.getString("name"));
                book.setAuthor(result.getString("author"));
                book.setIsbn(result.getInt("ISBN"));
                book.setAmount(result.getInt("amount"));
                bookList.add(book);
            }
            //关闭jdbc连接
            statement.close();
            connection.close();
            return bookList;
        }
        catch (SQLException ClassNotFoundException) {
            ClassNotFoundException.printStackTrace();
            return null;
        }

    }
}
