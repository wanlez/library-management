package com.sqltest.springboottest.service;

import com.sqltest.springboottest.dao.BookDao;
import com.sqltest.springboottest.entity.IPage;
import com.sqltest.springboottest.entity.Book;
import com.sqltest.springboottest.entity.LogPacket;
import com.sqltest.springboottest.entity.SendPacket;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PathVariable;

@Component
public class BookService {
    @Autowired
    private BookDao bookDao;
    @Autowired
    private NumOpera numOp;

    public IPage findPage(Integer page, Integer size) { //让它调用dao层
        IPage pageI = new IPage();
        Integer base = page * size;
        pageI.setBookList(bookDao.findAll(base, size));
        //再通过PageI的list长度设置totalElement
        pageI.setTotalElement(bookDao.findTotalElem());
//        return pageI;
        return pageI;
    }

    public IPage findBook(Book book) { //让它调用dao层
        //有三个变量有些为空，该怎么查询
        IPage pageI = new IPage();
        if(book.getName() == null) {
            if (book.getAuthor() == null) {
                if (book.getIsbn() == null) {
                    return null; //全空
                } else {
                    //查ISBN
                    pageI.setBookList(bookDao.findBook(book.getIsbn()));
                }
            } else { //author不空
                if (book.getIsbn() == null) {
                    //查 author
                    pageI.setBookList(bookDao.findBook(book.getAuthor(), true));
                } else {
                    //查author ISBN
                    pageI.setBookList(bookDao.findBook(book.getAuthor(), book.getIsbn(), true));
                }
            }
        }
        else { //name不空
            if (book.getAuthor() == null) {
                if (book.getIsbn() == null) {
                    //查name
                    pageI.setBookList(bookDao.findBook(book.getName()));
                } else {
                    //查name ISBN
                    pageI.setBookList(bookDao.findBook(book.getName(), book.getIsbn()));
                }
            }
            else { //name author不空
                if (book.getIsbn() == null) {
                    //查 name author
                    pageI.setBookList(bookDao.findBook(book.getName(), book.getAuthor()));
                } else {
                    //查name author ISBN
                    pageI.setBookList(bookDao.findBook(book));
                }
            }
        }
        //再通过PageI的list长度设置totalElement
        pageI.setTotalElement(bookDao.findTotalElem());
        return pageI;
    }

    public Book save(Book book) {
        //给ISBN一个合理值
        //save目前只对add图书，并且amount必>0
        //看起来新书必定缺失一个ISBN
        book.setIsbn(numOp.findGapFromSQL());
        return bookDao.save(book);
    }

    public Book findById(Integer id) {
        return bookDao.findById(id);
    }

    public Book update(Book book) {
        //book.setISBN(numOp.findGapFromSQL());
        return bookDao.update(book);
    }

    public void deleteById(Integer id) {
        bookDao.deleteById(id);
    }
}
