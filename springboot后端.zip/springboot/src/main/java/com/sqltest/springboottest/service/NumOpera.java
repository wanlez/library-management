package com.sqltest.springboottest.service;
import com.sqltest.springboottest.dao.BookDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class NumOpera {
    @Autowired
    private BookDao bookDao;

    public Integer findGapFromSQL() {
        Integer i = bookDao.findGap();
        if(i == 0) { //没有间断返回最大的
            return bookDao.findTotalElem();
        }
        else  return i;
    }
}
