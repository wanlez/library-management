package com.sqltest.springboottest.dao;

import com.sqltest.springboottest.entity.LogPacket;
import com.sqltest.springboottest.util.JdbcUtil;
import org.springframework.stereotype.Component;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@Component
public class LogDao_Imp implements LogDao{
    @Override
    public LogPacket findAccount(LogPacket logpacket) { //sql找账号
        //获取数据库连接
        Connection connection = JdbcUtil.getConnection();
        LogPacket tranPass = new LogPacket();
        try {
            //需要执行的sql语句
            String sql = "select password, authority from secret where account = ?";
            //获取预处理对象，并给参数赋值
            PreparedStatement statement = connection.prepareCall(sql);
            statement.setString(1, logpacket.getAccount());
            //执行sql语句（插入了几条记录，就返回几）
            ResultSet result = statement.executeQuery();
            if(result.next()) {
                tranPass.setPassword(result.getString("password"));
                tranPass.setAuthority(result.getInt("authority"));
//                System.out.println(tranPass.getPassword());
//                System.out.println(tranPass.getAuthority());
                return tranPass;
            }
            //关闭jdbc连接
            statement.close();
            connection.close();
            return null;
        }
        catch (SQLException ClassNotFoundException) {
            ClassNotFoundException.printStackTrace();
            return null;
        }
    }

    @Override
    public LogPacket save(LogPacket logpacket) {
        //获取数据库连接
        Connection connection = JdbcUtil.getConnection();
        try {
            //需要执行的sql语句
            String sql = "insert into secret(account, password, authority) values(?,?,?)";
            //获取预处理对象，并给参数赋值
            PreparedStatement statement = connection.prepareCall(sql);
            statement.setString(1, logpacket.getAccount());
            statement.setString(2, logpacket.getPassword());
            statement.setInt(3, 0);
            //执行sql语句（插入了几条记录，就返回几）
            int i = statement.executeUpdate();  //executeUpdate：执行并更新
            //System.out.println(i);
            //关闭jdbc连接
            statement.close();
            connection.close();
            return logpacket;
        }
        catch (SQLException ClassNotFoundException) {
            ClassNotFoundException.printStackTrace();
            return null;
        }
    }
}
